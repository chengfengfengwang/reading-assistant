const t={prompts:[{id:"1",title:"translate",content:"translate these content: "}]};export{t as d};
