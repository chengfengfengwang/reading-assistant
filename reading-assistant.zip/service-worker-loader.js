import 'http://localhost:7788/@vite/env';
import 'http://localhost:7788/@crx/client-worker';
import 'http://localhost:7788/src/pages/background/index.ts';
